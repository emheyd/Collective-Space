package com.example.collectivespace;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;
import com.robertlevonyan.views.chip.Chip;
import java.util.ArrayList;

public class feedbackpage extends AppCompatActivity {

    ArrayList<String> chipList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedbackpage);
        chipList = getIntent().getStringArrayListExtra("chips");
        Toast toast=Toast.makeText(getApplicationContext(),String.valueOf(chipList.size()),Toast.LENGTH_SHORT);
        toast.setMargin(50,50);
        toast.show();
    }

}
